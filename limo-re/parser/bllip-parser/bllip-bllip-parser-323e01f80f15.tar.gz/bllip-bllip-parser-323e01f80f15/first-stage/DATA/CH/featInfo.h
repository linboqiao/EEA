3

  1   hu     0  0 |
  2   hut    1  1 |
  3   hutc   2  2 |
  4   hutcv  3  3 |
  5   hutcvm 4  4 |
  6   hutcvi 5  4 |

--

  0    u   2  1 |
  1    t   0  2 |
  2    c   12 3 |
  3    v   6  4 |
  4    m   9  5 |
  5    i   4  6 |

--

--

FactorPos= 3
