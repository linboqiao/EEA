// custom_allocator.h
//
// Mark Johnson, 23rd April 2005, modified 21st February 2010

